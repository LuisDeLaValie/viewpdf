package com.syncfusion.syncfusion_flutter_pdfviewer_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
