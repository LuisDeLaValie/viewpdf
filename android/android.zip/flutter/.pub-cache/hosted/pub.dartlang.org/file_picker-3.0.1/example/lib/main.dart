import 'package:file_picker_example/src/file_picker_demo.dart';
import 'package:flutter/widgets.dart';

void main() => runApp(new FilePickerDemo());
