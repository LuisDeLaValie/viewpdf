---
name: Suggestion
about: Add a new suggestion
title: ''
labels: suggestion

---

I encourage you to add new suggestions that you think that can make file_picker even a better package.

_**Note:**_: Before creating a new suggestion, make sure it isn't already listed. Filter by [suggestion] tag.